﻿namespace Lab2B
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.hairDresserGroupBox = new System.Windows.Forms.GroupBox();
            this.lauraRenkinsRadioBtn = new System.Windows.Forms.RadioButton();
            this.suePallonRadioBtn = new System.Windows.Forms.RadioButton();
            this.ronChambersRadioBtn = new System.Windows.Forms.RadioButton();
            this.patJohnsonRadioBtn = new System.Windows.Forms.RadioButton();
            this.janeSamleyRadioBtn = new System.Windows.Forms.RadioButton();
            this.servicesGroupBox = new System.Windows.Forms.GroupBox();
            this.extensionsCheckBox = new System.Windows.Forms.CheckBox();
            this.highlightsCheckBox = new System.Windows.Forms.CheckBox();
            this.colourCheckBox = new System.Windows.Forms.CheckBox();
            this.cutCheckBox = new System.Windows.Forms.CheckBox();
            this.clientTypeGroupBox = new System.Windows.Forms.GroupBox();
            this.seniorRadioBtn = new System.Windows.Forms.RadioButton();
            this.studentRadioBtn = new System.Windows.Forms.RadioButton();
            this.childRadioBtn = new System.Windows.Forms.RadioButton();
            this.standardAdultRadioBtn = new System.Windows.Forms.RadioButton();
            this.clientVisitGroupBox = new System.Windows.Forms.GroupBox();
            this.numOfClientVisitsTextBox = new System.Windows.Forms.TextBox();
            this.numOfClientVisitsLabel = new System.Windows.Forms.Label();
            this.calculateBtn = new System.Windows.Forms.Button();
            this.clearBtn = new System.Windows.Forms.Button();
            this.exitBtn = new System.Windows.Forms.Button();
            this.totalPriceLabel = new System.Windows.Forms.Label();
            this.totalPriceValueLabel = new System.Windows.Forms.Label();
            this.hairDresserGroupBox.SuspendLayout();
            this.servicesGroupBox.SuspendLayout();
            this.clientTypeGroupBox.SuspendLayout();
            this.clientVisitGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // hairDresserGroupBox
            // 
            this.hairDresserGroupBox.Controls.Add(this.lauraRenkinsRadioBtn);
            this.hairDresserGroupBox.Controls.Add(this.suePallonRadioBtn);
            this.hairDresserGroupBox.Controls.Add(this.ronChambersRadioBtn);
            this.hairDresserGroupBox.Controls.Add(this.patJohnsonRadioBtn);
            this.hairDresserGroupBox.Controls.Add(this.janeSamleyRadioBtn);
            this.hairDresserGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hairDresserGroupBox.Location = new System.Drawing.Point(12, 42);
            this.hairDresserGroupBox.Name = "hairDresserGroupBox";
            this.hairDresserGroupBox.Size = new System.Drawing.Size(227, 223);
            this.hairDresserGroupBox.TabIndex = 0;
            this.hairDresserGroupBox.TabStop = false;
            this.hairDresserGroupBox.Text = "Hair Dresser";
            // 
            // lauraRenkinsRadioBtn
            // 
            this.lauraRenkinsRadioBtn.AutoSize = true;
            this.lauraRenkinsRadioBtn.Location = new System.Drawing.Point(6, 177);
            this.lauraRenkinsRadioBtn.Name = "lauraRenkinsRadioBtn";
            this.lauraRenkinsRadioBtn.Size = new System.Drawing.Size(111, 20);
            this.lauraRenkinsRadioBtn.TabIndex = 4;
            this.lauraRenkinsRadioBtn.TabStop = true;
            this.lauraRenkinsRadioBtn.Text = "Laura Renkins";
            this.lauraRenkinsRadioBtn.UseVisualStyleBackColor = true;
            // 
            // suePallonRadioBtn
            // 
            this.suePallonRadioBtn.AutoSize = true;
            this.suePallonRadioBtn.Location = new System.Drawing.Point(6, 141);
            this.suePallonRadioBtn.Name = "suePallonRadioBtn";
            this.suePallonRadioBtn.Size = new System.Drawing.Size(90, 20);
            this.suePallonRadioBtn.TabIndex = 3;
            this.suePallonRadioBtn.TabStop = true;
            this.suePallonRadioBtn.Text = "Sue Pallon";
            this.suePallonRadioBtn.UseVisualStyleBackColor = true;
            // 
            // ronChambersRadioBtn
            // 
            this.ronChambersRadioBtn.AutoSize = true;
            this.ronChambersRadioBtn.Location = new System.Drawing.Point(6, 104);
            this.ronChambersRadioBtn.Name = "ronChambersRadioBtn";
            this.ronChambersRadioBtn.Size = new System.Drawing.Size(115, 20);
            this.ronChambersRadioBtn.TabIndex = 2;
            this.ronChambersRadioBtn.TabStop = true;
            this.ronChambersRadioBtn.Text = "Ron Chambers";
            this.ronChambersRadioBtn.UseVisualStyleBackColor = true;
            // 
            // patJohnsonRadioBtn
            // 
            this.patJohnsonRadioBtn.AutoSize = true;
            this.patJohnsonRadioBtn.Location = new System.Drawing.Point(6, 67);
            this.patJohnsonRadioBtn.Name = "patJohnsonRadioBtn";
            this.patJohnsonRadioBtn.Size = new System.Drawing.Size(99, 20);
            this.patJohnsonRadioBtn.TabIndex = 1;
            this.patJohnsonRadioBtn.TabStop = true;
            this.patJohnsonRadioBtn.Text = "Pat Johnson";
            this.patJohnsonRadioBtn.UseVisualStyleBackColor = true;
            // 
            // janeSamleyRadioBtn
            // 
            this.janeSamleyRadioBtn.AutoSize = true;
            this.janeSamleyRadioBtn.Checked = true;
            this.janeSamleyRadioBtn.Location = new System.Drawing.Point(6, 32);
            this.janeSamleyRadioBtn.Name = "janeSamleyRadioBtn";
            this.janeSamleyRadioBtn.Size = new System.Drawing.Size(104, 20);
            this.janeSamleyRadioBtn.TabIndex = 0;
            this.janeSamleyRadioBtn.TabStop = true;
            this.janeSamleyRadioBtn.Text = "Jane Samley";
            this.janeSamleyRadioBtn.UseVisualStyleBackColor = true;
            // 
            // servicesGroupBox
            // 
            this.servicesGroupBox.Controls.Add(this.extensionsCheckBox);
            this.servicesGroupBox.Controls.Add(this.highlightsCheckBox);
            this.servicesGroupBox.Controls.Add(this.colourCheckBox);
            this.servicesGroupBox.Controls.Add(this.cutCheckBox);
            this.servicesGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.servicesGroupBox.Location = new System.Drawing.Point(254, 42);
            this.servicesGroupBox.Name = "servicesGroupBox";
            this.servicesGroupBox.Size = new System.Drawing.Size(228, 223);
            this.servicesGroupBox.TabIndex = 1;
            this.servicesGroupBox.TabStop = false;
            this.servicesGroupBox.Text = "Services";
            // 
            // extensionsCheckBox
            // 
            this.extensionsCheckBox.AutoSize = true;
            this.extensionsCheckBox.Location = new System.Drawing.Point(7, 141);
            this.extensionsCheckBox.Name = "extensionsCheckBox";
            this.extensionsCheckBox.Size = new System.Drawing.Size(91, 20);
            this.extensionsCheckBox.TabIndex = 3;
            this.extensionsCheckBox.Text = "Extensions";
            this.extensionsCheckBox.UseVisualStyleBackColor = true;
            // 
            // highlightsCheckBox
            // 
            this.highlightsCheckBox.AutoSize = true;
            this.highlightsCheckBox.Location = new System.Drawing.Point(7, 104);
            this.highlightsCheckBox.Name = "highlightsCheckBox";
            this.highlightsCheckBox.Size = new System.Drawing.Size(85, 20);
            this.highlightsCheckBox.TabIndex = 2;
            this.highlightsCheckBox.Text = "Highlights";
            this.highlightsCheckBox.UseVisualStyleBackColor = true;
            // 
            // colourCheckBox
            // 
            this.colourCheckBox.AutoSize = true;
            this.colourCheckBox.Location = new System.Drawing.Point(7, 67);
            this.colourCheckBox.Name = "colourCheckBox";
            this.colourCheckBox.Size = new System.Drawing.Size(65, 20);
            this.colourCheckBox.TabIndex = 1;
            this.colourCheckBox.Text = "Colour";
            this.colourCheckBox.UseVisualStyleBackColor = true;
            // 
            // cutCheckBox
            // 
            this.cutCheckBox.AutoSize = true;
            this.cutCheckBox.Location = new System.Drawing.Point(6, 32);
            this.cutCheckBox.Name = "cutCheckBox";
            this.cutCheckBox.Size = new System.Drawing.Size(45, 20);
            this.cutCheckBox.TabIndex = 0;
            this.cutCheckBox.Text = "Cut";
            this.cutCheckBox.UseVisualStyleBackColor = true;
            // 
            // clientTypeGroupBox
            // 
            this.clientTypeGroupBox.Controls.Add(this.seniorRadioBtn);
            this.clientTypeGroupBox.Controls.Add(this.studentRadioBtn);
            this.clientTypeGroupBox.Controls.Add(this.childRadioBtn);
            this.clientTypeGroupBox.Controls.Add(this.standardAdultRadioBtn);
            this.clientTypeGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clientTypeGroupBox.Location = new System.Drawing.Point(13, 286);
            this.clientTypeGroupBox.Name = "clientTypeGroupBox";
            this.clientTypeGroupBox.Size = new System.Drawing.Size(226, 227);
            this.clientTypeGroupBox.TabIndex = 2;
            this.clientTypeGroupBox.TabStop = false;
            this.clientTypeGroupBox.Text = "Client Type";
            // 
            // seniorRadioBtn
            // 
            this.seniorRadioBtn.AutoSize = true;
            this.seniorRadioBtn.Location = new System.Drawing.Point(7, 156);
            this.seniorRadioBtn.Name = "seniorRadioBtn";
            this.seniorRadioBtn.Size = new System.Drawing.Size(121, 20);
            this.seniorRadioBtn.TabIndex = 3;
            this.seniorRadioBtn.TabStop = true;
            this.seniorRadioBtn.Text = "Senior (Over 65)";
            this.seniorRadioBtn.UseVisualStyleBackColor = true;
            // 
            // studentRadioBtn
            // 
            this.studentRadioBtn.AutoSize = true;
            this.studentRadioBtn.Location = new System.Drawing.Point(7, 116);
            this.studentRadioBtn.Name = "studentRadioBtn";
            this.studentRadioBtn.Size = new System.Drawing.Size(70, 20);
            this.studentRadioBtn.TabIndex = 2;
            this.studentRadioBtn.TabStop = true;
            this.studentRadioBtn.Text = "Student";
            this.studentRadioBtn.UseVisualStyleBackColor = true;
            // 
            // childRadioBtn
            // 
            this.childRadioBtn.AutoSize = true;
            this.childRadioBtn.Location = new System.Drawing.Point(7, 76);
            this.childRadioBtn.Name = "childRadioBtn";
            this.childRadioBtn.Size = new System.Drawing.Size(143, 20);
            this.childRadioBtn.TabIndex = 1;
            this.childRadioBtn.TabStop = true;
            this.childRadioBtn.Text = "Child (12 and under)";
            this.childRadioBtn.UseVisualStyleBackColor = true;
            // 
            // standardAdultRadioBtn
            // 
            this.standardAdultRadioBtn.AutoSize = true;
            this.standardAdultRadioBtn.Checked = true;
            this.standardAdultRadioBtn.Location = new System.Drawing.Point(7, 37);
            this.standardAdultRadioBtn.Name = "standardAdultRadioBtn";
            this.standardAdultRadioBtn.Size = new System.Drawing.Size(113, 20);
            this.standardAdultRadioBtn.TabIndex = 0;
            this.standardAdultRadioBtn.TabStop = true;
            this.standardAdultRadioBtn.Text = "Standard Adult";
            this.standardAdultRadioBtn.UseVisualStyleBackColor = true;
            // 
            // clientVisitGroupBox
            // 
            this.clientVisitGroupBox.Controls.Add(this.numOfClientVisitsTextBox);
            this.clientVisitGroupBox.Controls.Add(this.numOfClientVisitsLabel);
            this.clientVisitGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clientVisitGroupBox.Location = new System.Drawing.Point(254, 286);
            this.clientVisitGroupBox.Name = "clientVisitGroupBox";
            this.clientVisitGroupBox.Size = new System.Drawing.Size(228, 227);
            this.clientVisitGroupBox.TabIndex = 3;
            this.clientVisitGroupBox.TabStop = false;
            this.clientVisitGroupBox.Text = "Client Visits";
            // 
            // numOfClientVisitsTextBox
            // 
            this.numOfClientVisitsTextBox.Location = new System.Drawing.Point(45, 74);
            this.numOfClientVisitsTextBox.Name = "numOfClientVisitsTextBox";
            this.numOfClientVisitsTextBox.Size = new System.Drawing.Size(137, 22);
            this.numOfClientVisitsTextBox.TabIndex = 1;
            // 
            // numOfClientVisitsLabel
            // 
            this.numOfClientVisitsLabel.AutoSize = true;
            this.numOfClientVisitsLabel.Location = new System.Drawing.Point(42, 37);
            this.numOfClientVisitsLabel.Name = "numOfClientVisitsLabel";
            this.numOfClientVisitsLabel.Size = new System.Drawing.Size(140, 16);
            this.numOfClientVisitsLabel.TabIndex = 0;
            this.numOfClientVisitsLabel.Text = "Number of Client Visits";
            // 
            // calculateBtn
            // 
            this.calculateBtn.Location = new System.Drawing.Point(18, 563);
            this.calculateBtn.Name = "calculateBtn";
            this.calculateBtn.Size = new System.Drawing.Size(123, 41);
            this.calculateBtn.TabIndex = 4;
            this.calculateBtn.Text = "Calculate";
            this.calculateBtn.UseVisualStyleBackColor = true;
            this.calculateBtn.Click += new System.EventHandler(this.calculateBtn_Click);
            // 
            // clearBtn
            // 
            this.clearBtn.Location = new System.Drawing.Point(182, 563);
            this.clearBtn.Name = "clearBtn";
            this.clearBtn.Size = new System.Drawing.Size(123, 41);
            this.clearBtn.TabIndex = 5;
            this.clearBtn.Text = "Clear";
            this.clearBtn.UseVisualStyleBackColor = true;
            this.clearBtn.Click += new System.EventHandler(this.clearBtn_Click);
            // 
            // exitBtn
            // 
            this.exitBtn.Location = new System.Drawing.Point(359, 563);
            this.exitBtn.Name = "exitBtn";
            this.exitBtn.Size = new System.Drawing.Size(123, 41);
            this.exitBtn.TabIndex = 6;
            this.exitBtn.Text = "Exit";
            this.exitBtn.UseVisualStyleBackColor = true;
            this.exitBtn.Click += new System.EventHandler(this.exitBtn_Click);
            // 
            // totalPriceLabel
            // 
            this.totalPriceLabel.AutoSize = true;
            this.totalPriceLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalPriceLabel.Location = new System.Drawing.Point(152, 525);
            this.totalPriceLabel.Name = "totalPriceLabel";
            this.totalPriceLabel.Size = new System.Drawing.Size(87, 20);
            this.totalPriceLabel.TabIndex = 7;
            this.totalPriceLabel.Text = "Total Price:";
            // 
            // totalPriceValueLabel
            // 
            this.totalPriceValueLabel.AutoSize = true;
            this.totalPriceValueLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalPriceValueLabel.Location = new System.Drawing.Point(257, 525);
            this.totalPriceValueLabel.Name = "totalPriceValueLabel";
            this.totalPriceValueLabel.Size = new System.Drawing.Size(0, 20);
            this.totalPriceValueLabel.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(502, 640);
            this.Controls.Add(this.totalPriceValueLabel);
            this.Controls.Add(this.totalPriceLabel);
            this.Controls.Add(this.exitBtn);
            this.Controls.Add(this.clearBtn);
            this.Controls.Add(this.calculateBtn);
            this.Controls.Add(this.clientVisitGroupBox);
            this.Controls.Add(this.clientTypeGroupBox);
            this.Controls.Add(this.servicesGroupBox);
            this.Controls.Add(this.hairDresserGroupBox);
            this.Name = "Form1";
            this.Text = "Perfect Cut Hair Salon";
            this.hairDresserGroupBox.ResumeLayout(false);
            this.hairDresserGroupBox.PerformLayout();
            this.servicesGroupBox.ResumeLayout(false);
            this.servicesGroupBox.PerformLayout();
            this.clientTypeGroupBox.ResumeLayout(false);
            this.clientTypeGroupBox.PerformLayout();
            this.clientVisitGroupBox.ResumeLayout(false);
            this.clientVisitGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox hairDresserGroupBox;
        private System.Windows.Forms.GroupBox servicesGroupBox;
        private System.Windows.Forms.GroupBox clientTypeGroupBox;
        private System.Windows.Forms.GroupBox clientVisitGroupBox;
        private System.Windows.Forms.RadioButton lauraRenkinsRadioBtn;
        private System.Windows.Forms.RadioButton suePallonRadioBtn;
        private System.Windows.Forms.RadioButton ronChambersRadioBtn;
        private System.Windows.Forms.RadioButton patJohnsonRadioBtn;
        private System.Windows.Forms.RadioButton janeSamleyRadioBtn;
        private System.Windows.Forms.CheckBox extensionsCheckBox;
        private System.Windows.Forms.CheckBox highlightsCheckBox;
        private System.Windows.Forms.CheckBox colourCheckBox;
        private System.Windows.Forms.CheckBox cutCheckBox;
        private System.Windows.Forms.RadioButton seniorRadioBtn;
        private System.Windows.Forms.RadioButton studentRadioBtn;
        private System.Windows.Forms.RadioButton childRadioBtn;
        private System.Windows.Forms.RadioButton standardAdultRadioBtn;
        private System.Windows.Forms.TextBox numOfClientVisitsTextBox;
        private System.Windows.Forms.Label numOfClientVisitsLabel;
        private System.Windows.Forms.Button calculateBtn;
        private System.Windows.Forms.Button clearBtn;
        private System.Windows.Forms.Button exitBtn;
        private System.Windows.Forms.Label totalPriceLabel;
        private System.Windows.Forms.Label totalPriceValueLabel;
    }
}

